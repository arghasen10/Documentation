/*
 * http-common.h
 *
 *  Created on: 09-Apr-2020
 *      Author: abhijit
 */

#ifndef SRC_SPDASH_MODEL_HTTP_HTTP_COMMON_H_
#define SRC_SPDASH_MODEL_HTTP_HTTP_COMMON_H_

#include <ns3/core-module.h>

namespace ns3 {

typedef uint64_t clen_t;


}

#endif /* SRC_SPDASH_MODEL_HTTP_HTTP_COMMON_H_ */
