
class QualityIndexError(Exception):
    pass

class ChunkIndexError(Exception):
    pass

